#!/bin/bash
# This script installs what is need for ScopyBio to run

echo ">>> Recupération de libstdc++6"
sudo DEBIAN_FRONTEND=noninteractive add-apt-repository -y ppa:ubuntu-toolchain-r/test
echo ">>> Update des paquets"
sudo DEBIAN_FRONTEND=noninteractive apt-get -y update
echo ">>> Upgrade des paquets"
sudo DEBIAN_FRONTEND=noninteractive apt-get -y upgrade
echo ">>> Installation de libstdc++6"
sudo DEBIAN_FRONTEND=noninteractive apt-get -y install libstdc++6
echo ">>> Création de l'exécutable"
chmod +x ./Build/bin/ScopyBio
echo ">>> Terminé"
