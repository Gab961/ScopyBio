Lancement version 1:
- Une première fois, installer les deux exécutables situés dans prérequis
- Lancer l'application via Build/bin/ScopyBio.exe